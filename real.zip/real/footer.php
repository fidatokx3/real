<?php wp_footer(); ?>
<h1>its the footer</h1>
