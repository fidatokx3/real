<?php wp_head(); ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
    <head>
        <meta charset="<?php bloginfo( 'charset' ); ?>" />
        <title><?php wp_title(); ?></title>
        <link rel="profile" href="http://gmpg.org/xfn/11" />
        <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
        <?php if ( is_singular() && get_option( 'thread_comments' ) ) wp_enqueue_script( 'comment-reply' ); ?>

    </head>
<body class="<?php body_class(); ?>">

 <div id="navbar" class="pos-f-t">

   <nav class="navbar navbar-dark ">
     <a class="navbar-brand" href="#">
       <img src="https://concordrealestatebd.com/themes/cms/assets/images/static/logo.svg" width="" height="" class="d-inline-block align-top" alt="">

     </a>
     <button class="navbar-toggler" onclick="openNav()" type="button" data-toggle="collapse" data-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
       <span class="navbar-toggler-icon"></span>
     </button>
   </nav>

 </div>


</head>

<div style="padding:15px 15px 2500px;font-size:30px;margin-top:30px;">
  <p><b>This example demonstrates how to hide a navbar when the user starts to scroll the page.</b></p>
  </div>
<script>
var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "0";
  } else {
    document.getElementById("navbar").style.top = "-77px";
  }
  prevScrollpos = currentScrollPos;
}
</script>






<!-- top top menu  ---->

<div id="myNav" class="overlay">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <div class="overlay-content">

      <div class="row">
        <div class="column">
          <!--a href="#">About</a>
          <a href="#">Services</a>
          <a href="#">Clients</a>
          <a href="#">Contact</a-->
          <?php wp_nav_menu( array(

              'menu'                 => '',
             'container'            => 'nav',
             'container_class'      => 'navbar navbar-expand-lg',
             'container_id'         => '',
             'container_aria_label' => '',
             'menu_class'           => 'menu',
             'menu_id'              => 'navbar-nav mr-auto',
             'echo'                 => true,
             'fallback_cb'          => 'wp_page_menu',
             'before'               => '',
             'after'                => '',
             'link_before'          => '',
             'link_after'           => '',
             'items_wrap'           => '<ul id="%1$s" class="navbar-nav">%3$s</ul>',
               'items_wrap'           => '<li id="" class="nav-item">%3$s</li>',
             'item_spacing'         => 'preserve',
             'depth'                => 0,
             'walker'               => '',
             'theme_location'       => 'header-menu',

         ) ); ?>
        </div>
        <div class="column">
          <h1>Hotline:</h1>
          <h2>16665</h2>
          <h3>International Callers:</h3>
          <h4>0 9612-111444</h4>
        </div>
      </div>
<div class="row">
  <div class="column">
    <h1>sdfssf</h1>
  </div>
  <div class="column">
    <h1>sdfssf</h1>
  </div>

</div>

  </div>
</div>



<script>
function openNav() {
  document.getElementById("myNav").style.height = "100%";
}

function closeNav() {
  document.getElementById("myNav").style.height = "0%";
}
</script>
